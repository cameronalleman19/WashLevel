const M$ = (id) => document.getElementById(id);

function mEsc(s){ const d = document.createElement("div"); d.textContent = s || ""; return d.innerHTML; }
function mMoney(n){ return "$" + (n || 0).toFixed(2); }
function mDate(t){ if (!t) return "--"; const d = new Date(t); return (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear(); }
function mMonthKey(d){ return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
function mAddMonths(d, n){ return new Date(d.getFullYear(), d.getMonth() + n, 1); }
function mMonthLabel(key){ const p = key.split("-"); return new Date(p[0], p[1] - 1, 1).toLocaleString("en-US", {month: "short", year: "numeric"}); }

let mConsumers = {}, mHist = {}, mSites = [], mViaSeen = {}, mCohortBase = {};
let mSelectedSite = null;
function mFilteredSites(){ return mSelectedSite ? mSites.filter(s => s.id === mSelectedSite) : mSites; }

async function memLoad(){
  const st = (await chrome.storage.local.get(["consumers", "hist", "sites", "viaSeen", "memCohortBase", "deviceSiteMap"])) || {};
  mDevMap = st.deviceSiteMap || {};
  // For each "parent" name, the sites of known devices that are that parent or share it:
  // "Cumberland" and "Cumberland - Bay 1" both register under parent "Cumberland".
  mDevBase = {};
  const par = function(d){ const i = d.lastIndexOf(" - "); return i > 0 ? d.slice(0, i).trim() : null; };
  const reg = function(k, sid){ (mDevBase[k] = mDevBase[k] || {})[sid] = true; };
  for (const d of Object.keys(mDevMap)){ reg(d, mDevMap[d]); const p = par(d); if (p) reg(p, mDevMap[d]); }
  mConsumers = st.consumers || {};
  mHist = st.hist || {};
  mSites = st.sites || [];
  mViaSeen = st.viaSeen || {};
  mCohortBase = st.memCohortBase || {};
  mDevInfer = {};
  try { mInferDevices(); } catch (e) { console.error("[Sidecar] device inference failed", e); }
}

function mHasBuckets(){
  return Object.values(mConsumers).some(c => c.months && Object.keys(c.months).length);
}

function mRecentRate(c){
  const now = new Date();
  const months = c.months || {};
  const curKey = mMonthKey(now);
  const prevD = mAddMonths(now, -1);
  const prevKey = mMonthKey(prevD);
  const dim = new Date(prevD.getFullYear(), prevD.getMonth() + 1, 0).getDate();
  const days = now.getDate() + dim;
  const n = (months[curKey] || 0) + (months[prevKey] || 0);
  return n / days * 30;
}

function mBaseline(c){
  const now = new Date();
  const months = c.months || {};
  let n = 0, tot = 0;
  for (let i = 2; i <= 13; i++){
    const d = mAddMonths(now, -i);
    if (c.signup && d < mAddMonths(new Date(c.signup), 0)) break;
    tot += months[mMonthKey(d)] || 0;
    n++;
  }
  return n >= 2 ? tot / n : null;
}

function mViaRecent(c){
  const cut = Date.now() - 45 * 86400000;
  const nameKey = (c.name || "").toLowerCase().replace(/[^a-z]/g, "");
  for (const k of Object.keys(mViaSeen || {})){
    const nk = String(k).toLowerCase().replace(/[^a-z0-9-]/g, "");
    if (nk !== c.id.toLowerCase() && nk !== nameKey) continue;
    const v = mViaSeen[k];
    if (Array.isArray(v)){
      for (const x of v){
        const t = (x && typeof x === "object") ? (x.t || x.time || 0) : x;
        if (typeof t === "number" && t > cut) return true;
      }
    } else if (typeof v === "number"){
      if (v > cut) return true;
    } else if (v){
      return true;
    }
  }
  return false;
}

function mIsCancelled(c){
  return !!(c.cancelled && c.cancelled > (c.lastNew || 0));
}

function mScore(c){
  const reasons = [];
  let score = 0;
  const now = Date.now();
  const tenure = c.signup ? (now - c.signup) / 86400000 : 9999;
  const dormant = c.lastWash ? (now - c.lastWash) / 86400000 : tenure;
  const recent = mRecentRate(c);
  const base = mBaseline(c);
  if (dormant > 21 && dormant < 9000){ score += 40; reasons.push("No wash in " + Math.round(dormant) + "d"); }
  if (base !== null && base >= 2 && recent < base * 0.5){ score += 30; reasons.push("Usage down " + Math.round((1 - recent / base) * 100) + "%"); }
  if (tenure < 60 && consPerMonth(c) < 2){ score += 20; reasons.push("New member, low usage"); }
  if (mViaRecent(c)){ score += 15; reasons.push("Recent VIA exception"); }
  return {score: score, reasons: reasons, recent: recent, base: base};
}

function mRenderChart(){
  const cv = M$("memChart");
  if (!cv || typeof wlLineChart !== "function") return;
  const today = new Date();
  const labels = [], vals = [];
  for (let i = 29; i >= 0; i--){
    const d = new Date(today); d.setDate(d.getDate() - i);
    const k = mDs(d);
    labels.push(k);
    vals.push(mMemberDay(k).rev);
  }
  wlLineChart(cv, labels, vals);
}

function mNormName(x){ return String(x || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }
let mDevMap = {}, mDevBase = {}, mDevInfer = {}, mDevInferInfo = [];

// When Dencar can't tell us a device's site, infer it from who uses it: a bay whose washes come mostly
// from one site's members (by their favorite site) belongs to that site. Needs 15+ washes and a 50%+ majority.
function mInferDevices(){
  mDevInfer = {};
  mDevInferInfo = [];
  const cache = {}, counts = {};
  for (const c of Object.values(mConsumers)){
    if (!c.use) continue;
    const fav = /^[\s\-\u2013\u2014]*$/.test(c.favSite || "") ? "" : c.favSite;
    const home = fav ? mSiteIdFor(fav, cache) : null;
    if (!home) continue;
    for (const mk of Object.keys(c.use)){
      const w = c.use[mk].w || {};
      for (const ws of Object.keys(w)){
        const d = ws.replace(/\s+/g, " ").trim();
        if (mSiteIdFor(d, cache)) continue;
        const o = counts[d] = counts[d] || {};
        o[home] = (o[home] || 0) + w[ws];
      }
    }
  }
  for (const d of Object.keys(counts)){
    const o = counts[d];
    let tot = 0, top = null, tn = 0;
    for (const sid of Object.keys(o)){ tot += o[sid]; if (o[sid] > tn){ tn = o[sid]; top = sid; } }
    if (tot >= 15 && tn / tot >= 0.5){ mDevInfer[d] = top; mDevInferInfo.push({d: d, sid: top, share: tn / tot, n: tot}); }
  }
  mDevInferInfo.sort(function(a, b){ return b.n - a.n; });
}
// "201 N 2nd St" and "201 2nd Street" both become "201|2nd": house number + first street word.
function mAddrKey(x){
  const t = String(x || "").toLowerCase().replace(/[.,#]/g, " ").split(/\s+/).filter(Boolean);
  const i = t.findIndex(function(w){ return /^\d+[a-z]?$/.test(w); });
  if (i < 0) return null;
  const dirs = {n: 1, s: 1, e: 1, w: 1, north: 1, south: 1, east: 1, west: 1, ne: 1, nw: 1, se: 1, sw: 1};
  let j = i + 1;
  while (j < t.length && dirs[t[j]]) j++;
  return j < t.length ? t[i] + "|" + t[j] : null;
}
function mSiteWords(x){ return String(x || "").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean); }
// Matches a Dencar device name ("Mermaid - Dillsburg - Tunnel 1") or favorite-site text to a site.
// 1) longest site name the text starts with; 2) the site whose distinctive words (not shared by most sites) all appear.
function mSiteIdFor(name, cache){
  const raw = String(name || "").trim();
  const n = mNormName(raw);
  if (!n) return null;
  if (cache[n] !== undefined) return cache[n];
  const dm = mDevMap[raw.replace(/\s+/g, " ")];
  if (dm && mSites.some(function(s){ return s.id === dm; })){ cache[n] = dm; return dm; }
  const rw = raw.replace(/\s+/g, " ");
  const pi = rw.lastIndexOf(" - ");
  if (pi > 0){
    const cand = mDevBase[rw.slice(0, pi).trim()];
    const ids = cand ? Object.keys(cand) : [];
    if (ids.length === 1 && mSites.some(function(s){ return s.id === ids[0]; })){ cache[n] = ids[0]; return ids[0]; }
  }
  let hit = null, best = 0;
  const ak = mAddrKey(raw);
  if (ak){
    const byAddr = mSites.filter(function(s){ return s.address && mAddrKey(s.address) === ak; });
    if (byAddr.length === 1){ cache[n] = byAddr[0].id; return byAddr[0].id; }
  }
  for (const s of mSites){ const sn = mNormName(s.name); if (sn && n.indexOf(sn) === 0 && sn.length > best){ best = sn.length; hit = s.id; } }
  if (!hit){
    const freq = {};
    mSites.forEach(function(s){ Array.from(new Set(mSiteWords(s.name))).forEach(function(w){ freq[w] = (freq[w] || 0) + 1; }); });
    const lim = Math.max(2, mSites.length / 2);
    const have = new Set(mSiteWords(raw));
    const cands = mSites.map(function(s){ return {s: s, d: mSiteWords(s.name).filter(function(w){ return freq[w] < lim; })}; })
      .filter(function(x){ return x.d.length && x.d.every(function(w){ return have.has(w); }); })
      .sort(function(a, b){ return b.d.length - a.d.length; });
    if (cands.length && (cands.length === 1 || cands[0].d.length > cands[1].d.length)) hit = cands[0].s.id;
  }
  if (!hit && mDevInfer[rw] && mSites.some(function(s){ return s.id === mDevInfer[rw]; })) hit = mDevInfer[rw];
  cache[n] = hit;
  return hit;
}

// Each member's payments for a month are split across sites by where they washed that month.
// Months with no washes stay with the member's home (favorite) site.
function mRenderUsageSplit(){
  const el = M$("memUsageSplit");
  if (!el) return;
  const tr = mTimeRange();
  const m1 = tr.from.slice(0, 7), m2 = tr.to.slice(0, 7);
  const tfv = (M$("memTimeFrame") || {}).value || "mtd";
  const rows = {};
  for (const s of mSites) rows[s.id] = {collected: 0, earned: 0, washes: 0, fromOthers: 0, homeAway: 0, homeWashes: 0};
  const grid = {};
  const cache = {};
  let any = false, noHome = 0, noHomeAmt = 0;
  const missWash = {}, missFav = {};
  let noFav = 0, guessed = 0;
  for (const c of Object.values(mConsumers)){
    if (!c.use) continue;
    const favTxt = /^[\s\-\u2013\u2014]*$/.test(c.favSite || "") ? "" : c.favSite;
    const favHome = mSiteIdFor(favTxt, cache);
    for (const mk of Object.keys(c.use)){
      if (mk < m1 || mk > m2) continue;
      const u = c.use[mk];
      any = true;
      let home = favHome;
      if (!home && !favTxt){
        let bestN = 0;
        for (const ws of Object.keys(u.w)){ const sid = mSiteIdFor(ws, cache); if (sid && rows[sid] && u.w[ws] > bestN){ bestN = u.w[ws]; home = sid; } }
        if (home) guessed++;
      }
      if (home && rows[home]) rows[home].collected += u.p; else { noHome++; noHomeAmt += u.p; if (favTxt) missFav[favTxt] = (missFav[favTxt] || 0) + 1; else noFav++; }
      const matched = [];
      let tot = 0;
      for (const ws of Object.keys(u.w)){
        const sid = mSiteIdFor(ws, cache);
        if (sid && rows[sid]){ matched.push([sid, u.w[ws]]); tot += u.w[ws]; } else missWash[ws] = (missWash[ws] || 0) + u.w[ws];
      }
      if (!tot){ if (home && rows[home]) rows[home].earned += u.p; continue; }
      for (const pair of matched){
        const sid = pair[0], n = pair[1];
        rows[sid].earned += u.p * n / tot;
        rows[sid].washes += n;
        if (home && rows[home]){
          rows[home].homeWashes += n;
          if (sid !== home){ rows[sid].fromOthers += n; rows[home].homeAway += n; }
          grid[home] = grid[home] || {};
          grid[home][sid] = (grid[home][sid] || 0) + n;
        }
      }
    }
  }
  if (!any){
    el.innerHTML = "<p>No usage history yet. Run <b>Sync Payment History</b> on the Consumers page to start tracking where members wash. " +
      "To fill in past months, rebuild once (takes about as long as your first Consumers sync).</p><button id=\"memUsageRebuildBtn\">Rebuild usage history</button> <span id=\"memUsageRebuildStatus\"></span>";
  } else {
    const sites = mFilteredSites();
    let html = "<p style=\"color:#8fa3c0;font-size:13px;margin:0 0 8px\">" + mEsc(tr.label) +
      (/^(today|7d|30d)$/.test(tfv) ? " - membership payments are monthly, so this shows the whole month" + (m1 !== m2 ? "s it touches" : "") : "") + "</p>";
    html += "<table class=\"via\"><thead><tr><th>Site</th><th>Collected</th><th>Earned by washes</th><th>Difference</th><th>Member washes</th><th>From other sites' members</th><th>Own members washing elsewhere</th></tr></thead><tbody>";
    let tc = 0, te = 0;
    for (const s of sites){
      const r = rows[s.id];
      const d = r.earned - r.collected;
      tc += r.collected; te += r.earned;
      html += "<tr><td>" + mEsc(s.name) + "</td><td>" + mMoney0(r.collected) + "</td><td>" + mMoney0(r.earned) + "</td>" +
        "<td style=\"color:" + (d >= 0 ? "#4ade80" : "#f87171") + "\">" + (d >= 0 ? "+" : "-") + mMoney0(Math.abs(d)) + "</td>" +
        "<td>" + r.washes.toLocaleString() + "</td><td>" + (r.washes ? Math.round(r.fromOthers / r.washes * 100) : 0) + "%</td>" +
        "<td>" + (r.homeWashes ? Math.round(r.homeAway / r.homeWashes * 100) : 0) + "%</td></tr>";
    }
    if (sites.length > 1) html += "<tr style=\"font-weight:700\"><td>All sites</td><td>" + mMoney0(tc) + "</td><td>" + mMoney0(te) + "</td><td></td><td></td><td></td><td></td></tr>";
    html += "</tbody></table>";
    html += "<p style=\"color:#8fa3c0;font-size:13px;margin:8px 0 0\">Collected = membership payments (before tax) from members whose favorite site is this site. " +
      "Earned = the same payments split by where those members actually washed that month - a $30 member who washed 5 times at A, 3 at B and 2 at C earns A $15, B $9 and C $6. " +
      "Months with no washes stay with the home site." + (guessed ? " " + guessed + " member-month" + (guessed === 1 ? " has" : "s have") + " no favorite site in Dencar, so " + (guessed === 1 ? "it's" : "they're") + " credited to the site washed at most." : "") + "</p>";
    const top = function(o){ return Object.keys(o).sort(function(a, b){ return o[b] - o[a]; }).slice(0, 5).map(function(k){ return "\"" + mEsc(k) + "\" (" + o[k] + ")"; }).join(", "); };
    const warn = [];
    if (noFav) warn.push(noFav + " member-months are from members with no favorite site and no washes to go by.");
    if (Object.keys(missFav).length) warn.push("Favorite sites that don't match a site: " + top(missFav) + ".");
    if (Object.keys(missWash).length) warn.push("Wash devices that don't match a site: " + top(missWash) + ".");
    if (mDevInferInfo.length){
      const nm = function(id){ const s = mSites.find(function(x){ return x.id === id; }); return s ? s.name : id; };
      html += "<p style=\"color:#8fa3c0;font-size:13px;margin:8px 0 0\">Matched by who uses them: " + mDevInferInfo.slice(0, 6).map(function(x){
        return "\"" + mEsc(x.d) + "\" &rarr; " + mEsc(nm(x.sid)) + " (" + Math.round(x.share * 100) + "% of its washes are that site's members)";
      }).join(", ") + (mDevInferInfo.length > 6 ? ", and " + (mDevInferInfo.length - 6) + " more" : "") + ".</p>";
    }
    if (warn.length) html += "<p style=\"color:#ffd166;font-size:13px;margin:8px 0 0\">" + warn.join(" ") + "</p>";
    if (Object.keys(missWash).length) html += "<p style=\"margin:6px 0 0\"><button id=\"memDevMapBtn\" style=\"font-size:13px;padding:6px 14px\">Match devices to sites</button> <span id=\"memDevMapStatus\" style=\"color:#8fa3c0;font-size:13px\">Asks Dencar which site each device belongs to.</span></p>";
    if (mSites.length > 1){
      html += "<h3 style=\"font-size:14px;margin:16px 0 8px\">Who washes where <small style=\"color:#8fa3c0;font-weight:400\">(share of each home site's member washes)</small></h3>";
      html += "<table class=\"via\"><thead><tr><th>Home site</th>" + mSites.map(function(s){ return "<th>" + mEsc(s.name) + "</th>"; }).join("") + "</tr></thead><tbody>";
      for (const h of mSites){
        const g = grid[h.id] || {};
        const tot = Object.values(g).reduce(function(a, b){ return a + b; }, 0);
        html += "<tr><td>" + mEsc(h.name) + "</td>" + mSites.map(function(s){
          const v = tot ? (g[s.id] || 0) / tot : 0;
          return "<td" + (s.id === h.id ? " style=\"font-weight:700\"" : "") + ">" + (tot ? Math.round(v * 100) + "%" : "--") + "</td>";
        }).join("") + "</tr>";
      }
      html += "</tbody></table>";
    }
    html += "<p style=\"margin-top:10px\"><button id=\"memUsageRebuildBtn\" style=\"font-size:13px;padding:6px 14px\">Rebuild usage history</button> <span id=\"memUsageRebuildStatus\" style=\"color:#8fa3c0;font-size:13px\">Only needed once, to fill in months from before usage tracking started. Saves after every month, so it can resume if it stops.</span></p>";
    el.innerHTML = html;
  }
  const dmb = M$("memDevMapBtn");
  if (dmb) dmb.addEventListener("click", async function(){
    if (typeof consLearnDeviceMap !== "function") return;
    dmb.disabled = true;
    const st = M$("memDevMapStatus");
    let ok = false;
    try { ok = await consLearnDeviceMap(function(t){ if (st) st.textContent = t; }); } finally { dmb.disabled = false; }
    const msg = st ? st.textContent : "";
    await memLoad();
    mRenderUsageSplit();
    const st2 = M$("memDevMapStatus");
    if (st2 && !ok) st2.textContent = msg || "Couldn't reach Dencar - make sure you're logged in and try again.";
  });
  const btn = M$("memUsageRebuildBtn");
  if (btn){
    chrome.storage.local.get(["usageRebuild"]).then(function(r){
      const ck = (r && r.usageRebuild) || null;
      const s = M$("memUsageRebuildStatus");
      if (ck && ck.v !== 2 && ck.complete){ if (s) s.textContent = "Press once more - an improved rebuild matches wash devices and favorite sites correctly."; }
      else if (ck && ck.v === 2 && !ck.complete && (ck.done || ck.monthsComplete)){ btn.textContent = "Resume usage rebuild"; if (s) s.textContent = ck.monthsComplete ? "Months done - press to finish looking up favorite sites." : "Stopped after " + ck.done + " - press to continue from there."; }
      else if (ck && ck.v === 2 && ck.complete){ if (s) s.textContent = "Rebuilt through " + ck.boundary + ". Regular Consumers syncs keep it current."; }
    });
    btn.addEventListener("click", async function(){
      if (typeof consRebuildUsage !== "function") return;
      const r = (await chrome.storage.local.get(["usageRebuild"])) || {};
      const ck = r.usageRebuild || null;
      const resuming = ck && ck.v === 2 && !ck.complete && (ck.done || ck.monthsComplete);
      if (!resuming && !confirm("Rebuild usage history from your Dencar payment history? It goes one month at a time and saves as it goes, so you can stop and resume.")) return;
      if (ck && ck.complete) await chrome.storage.local.set({usageRebuild: {}});
      btn.disabled = true;
      const st = M$("memUsageRebuildStatus");
      try { await consRebuildUsage(function(t){ if (st) st.textContent = t; }); }
      finally { btn.disabled = false; }
      const keep = st ? st.textContent : "";
      await memLoad();
      mRenderUsageSplit();
      const st2 = M$("memUsageRebuildStatus");
      if (st2 && keep) st2.textContent = keep;
    });
  }
}

function mInitCollapsible(){
  const page = document.getElementById("page-members");
  if (!page) return;
  const prefs = JSON.parse(localStorage.getItem("memCollapsed") || "{}");
  page.querySelectorAll("h2").forEach(h => {
    const key = h.textContent.trim().replace(/\s*[\u25B6\u25BC]\s*$/, "").trim();
    // Wrap following siblings until next h2 in a container div
    let wrap = h.nextElementSibling;
    if (wrap && wrap.classList.contains("mem-collapse-wrap")) return; // already initialized
    const div = document.createElement("div");
    div.className = "mem-collapse-wrap";
    let sib = h.nextSibling;
    while (sib && !(sib.nodeType === 1 && sib.tagName === "H2")){
      const next = sib.nextSibling;
      div.appendChild(sib);
      sib = next;
    }
    h.parentNode.insertBefore(div, sib);
    // Add arrow
    const arrow = document.createElement("span");
    arrow.className = "collapse-arrow";
    arrow.style.cssText = "margin-left:8px;font-size:12px";
    h.appendChild(arrow);
    // Apply saved state
    const collapsed = prefs[key] || false;
    div.style.display = collapsed ? "none" : "";
    arrow.textContent = collapsed ? "\u25B6" : "\u25BC";
    // Click handler
    h.style.cursor = "pointer";
    h.addEventListener("click", () => {
      const isHidden = div.style.display === "none";
      div.style.display = isHidden ? "" : "none";
      arrow.textContent = isHidden ? "\u25BC" : "\u25B6";
      const p = JSON.parse(localStorage.getItem("memCollapsed") || "{}");
      p[key] = !isHidden;
      localStorage.setItem("memCollapsed", JSON.stringify(p));
    });
  });
}

function mRenderLostMembers(){
  const tb = M$("memLostBody");
  if (!tb) return;
  const sel = M$("memLostPeriod");
  const days = sel ? parseInt(sel.value) || 30 : 30;
  const cut = Date.now() - days * 86400000;
  const lost = Object.values(mConsumers).filter(c => {
    if (!c.signup) return false;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    if (!lastBill) return false;
    // Cancelled after cutoff
    if (c.cancelled && c.cancelled > (c.lastNew || 0) && c.cancelled > cut) return true;
    // Expired: last billing > 45 days ago but not actively cancelled, and was active before
    if (!c.cancelled || c.cancelled <= (c.lastNew || 0)){
      if (lastBill < Date.now() - 45 * 86400000 && lastBill > cut) return true;
    }
    return false;
  });
  if (!lost.length){
    tb.innerHTML = "<tr><td colspan=\"6\">No recently lost members in this period.</td></tr>";
    return;
  }
  lost.sort((a, b) => {
    const aT = a.cancelled && a.cancelled > (a.lastNew || 0) ? a.cancelled : Math.max(a.lastNew || 0, a.lastRenew || 0);
    const bT = b.cancelled && b.cancelled > (b.lastNew || 0) ? b.cancelled : Math.max(b.lastNew || 0, b.lastRenew || 0);
    return bT - aT;
  });
  tb.innerHTML = "";
  for (const c of lost){
    const wasCancelled = c.cancelled && c.cancelled > (c.lastNew || 0);
    const reason = wasCancelled ? "Cancelled" : "Expired / Declined";
    const reasonStyle = wasCancelled ? "color:#f87171" : "color:#ffd166";
    const lostDate = wasCancelled ? c.cancelled : Math.max(c.lastNew || 0, c.lastRenew || 0);
    const phone = c.phone || "";
    const phoneClean = phone.replace(/[^0-9+]/g, "");
    const phoneLinks = phoneClean
      ? "<a href=\"tel:" + phoneClean + "\" class=\"via-open\">" + mEsc(phone) + "</a> <a href=\"sms:" + phoneClean + "\" class=\"via-open\" title=\"Text\">SMS</a>"
      : "--";
    const tr = document.createElement("tr");
    tr.innerHTML = "<td>" + mEsc(c.name || "(no name)") + "</td>" +
      "<td>" + phoneLinks + "</td>" +
      "<td style=\"" + reasonStyle + "\">" + reason + "</td>" +
      "<td>" + mDate(lostDate) + "</td>" +
      "<td>" + mEsc(c.washPlan || "--") + "</td>" +
      "<td><a class=\"via-open\" target=\"_blank\" href=\"" + DENCAR_BASE + "/consumer/" + c.id + "/\">Open</a></td>";
    tb.appendChild(tr);
  }
}

function mRenderIncomplete(){
  const tb = M$("memIncBody");
  if (!tb) return;
  const now = Date.now();
  const incomplete = Object.values(mConsumers).filter(c => {
    if (c.name && c.name !== "(no name)") return false;
    if (!c.signup) return false;
    const renew = new Date(c.signup);
    renew.setMonth(renew.getMonth() + 1);
    return renew.getTime() > now;
  });
  if (!incomplete.length){
    tb.innerHTML = "<tr><td colspan=\"5\">No incomplete signups " + String.fromCharCode(127881) + "</td></tr>";
    return;
  }
  incomplete.sort((a, b) => {
    const ra = new Date(a.signup); ra.setMonth(ra.getMonth() + 1);
    const rb = new Date(b.signup); rb.setMonth(rb.getMonth() + 1);
    return ra.getTime() - rb.getTime();
  });
  tb.innerHTML = "";
  for (const c of incomplete){
    const renew = new Date(c.signup);
    renew.setMonth(renew.getMonth() + 1);
    const daysLeft = Math.ceil((renew.getTime() - now) / 86400000);
    const phone = c.phone || "--";
    const phoneClean = phone.replace(/[^0-9+]/g, "");
    const phoneLinks = phoneClean
      ? "<a href=\"tel:" + phoneClean + "\" class=\"via-open\">" + mEsc(phone) + "</a> <a href=\"sms:" + phoneClean + "\" class=\"via-open\" title=\"Text\">SMS</a>"
      : mEsc(phone);
    const daysStyle = daysLeft <= 3
      ? " style=\"color:#f87171;font-weight:600\""
      : daysLeft <= 7
        ? " style=\"color:#ffd166;font-weight:600\""
        : "";
    const tr = document.createElement("tr");
    tr.innerHTML = "<td>" + phoneLinks + "</td>" +
      "<td>" + mDate(c.signup) + "</td>" +
      "<td" + daysStyle + ">" + daysLeft + "d</td>" +
      "<td>" + mEsc(c.favSite || "--") + "</td>" +
      "<td><a class=\"via-open\" target=\"_blank\" href=\"" + DENCAR_BASE + "/consumer/" + c.id + "/\">Open</a></td>";
    tb.appendChild(tr);
  }
}

function mRenderRisk(){
  const tb = M$("memRiskBody");
  tb.innerHTML = "";
  if (!mHasBuckets()){
    tb.innerHTML = "<tr><td colspan=\"6\">Monthly usage data not built yet. Go to Consumers and press Sync Consumers once, then Recalculate here.</td></tr>";
    return;
  }
  const scored = [];
  for (const c of Object.values(mConsumers)){
    if (mIsCancelled(c)) continue;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    if (!lastBill || Date.now() - lastBill > 45 * 86400000) continue;
    const r = mScore(c);
    if (r.score >= 25) scored.push({c: c, r: r});
  }
  scored.sort((a, b) => b.r.score - a.r.score);
  if (!scored.length){ tb.innerHTML = "<tr><td colspan=\"6\">No at-risk members flagged.</td></tr>"; return; }
  for (const x of scored.slice(0, 75)){
    const lvl = x.r.score >= 50 ? "HIGH" : "MED";
    const tr = document.createElement("tr");
    tr.innerHTML = "<td><a class=\"via-open\" target=\"_blank\" href=\"" + DENCAR_BASE + "/consumer/" + x.c.id + "/\">" + mEsc(x.c.name) + "</a></td>" +
      "<td>" + lvl + " (" + x.r.score + ")</td>" +
      "<td>" + mEsc(x.r.reasons.join("; ")) + "</td>" +
      "<td>" + x.r.recent.toFixed(1) + "</td>" +
      "<td>" + (x.r.base === null ? "--" : x.r.base.toFixed(1)) + "</td>" +
      "<td>" + mDate(x.c.lastWash) + "</td>";
    tb.appendChild(tr);
  }
}

async function mRenderCohorts(){
  const tb = M$("memCohortBody");
  tb.innerHTML = "";
  const now = new Date();
  const byCohort = {};
  for (const c of Object.values(mConsumers)){
    if (!c.signup) continue;
    const key = mMonthKey(new Date(c.signup));
    (byCohort[key] = byCohort[key] || []).push(c);
  }
  let changed = false;
  for (const key of Object.keys(byCohort)){
    if (!mCohortBase[key] || byCohort[key].length > mCohortBase[key]){ mCohortBase[key] = byCohort[key].length; changed = true; }
  }
  if (changed) await chrome.storage.local.set({memCohortBase: mCohortBase});
  const keys = Object.keys(byCohort).sort().slice(-13);
  let any = false;
  for (const key of keys){
    const p = key.split("-");
    const cohortStart = new Date(p[0], p[1] - 1, 1);
    if (mMonthKey(cohortStart) === mMonthKey(now)) continue;
    const base = mCohortBase[key] || byCohort[key].length;
    let cells = "";
    for (const n of [1, 3, 6, 12]){
      const target = mAddMonths(cohortStart, n);
      if (target >= mAddMonths(now, 0)){ cells += "<td>--</td>"; continue; }
      const end = mAddMonths(cohortStart, n + 1).getTime();
      const paying = byCohort[key].filter(c => !(c.cancelled && c.cancelled < end && c.cancelled > (c.lastNew || 0))).length;
      cells += "<td>" + Math.round(paying / base * 100) + "%</td>";
    }
    const tr = document.createElement("tr");
    tr.innerHTML = "<td>" + mMonthLabel(key) + "</td><td>" + base + "</td>" + cells;
    tb.appendChild(tr);
    any = true;
  }
  if (!any) tb.innerHTML = "<tr><td colspan=\"6\">No cohort data yet.</td></tr>";
}

function mDs(d){ return d.toLocaleDateString("en-CA"); }

function mMemberDay(dateStr){
  const out = {rev: 0, passUse: 0};
  for (const s of mFilteredSites()){
    const rec = (mHist[s.id] || {})[dateStr];
    if (!rec) continue;
    out.rev += (rec.newPassAmt || 0) + (rec.passRenewAmt || 0) + (rec.newPassOnlineAmt || 0) + (rec.onlineGiftAmt || 0) + (rec.viaAddAmt || 0);
    out.passUse += rec.passUse || 0;
  }
  return out;
}

function mMemberRange(from, to){
  const out = {rev: 0, passUse: 0};
  const d = new Date(from + "T00:00:00");
  const end = new Date(to + "T00:00:00");
  while (d <= end){
    const t = mMemberDay(mDs(d));
    out.rev += t.rev; out.passUse += t.passUse;
    d.setDate(d.getDate() + 1);
  }
  return out;
}

function mMoney0(n){ return "$" + Math.round(n || 0).toLocaleString("en-US"); }

function mTile(label, val){
  return "<div class=\"stat\"><label>" + label + "</label><div>" + val + "</div></div>";
}

function mAllTimeHigh(){
  const daySums = {};
  for (const s of mFilteredSites()){
    for (const dt of Object.keys(mHist[s.id] || {})){
      const v = mHist[s.id][dt].consumerVehicles || 0;
      if (v) daySums[dt] = (daySums[dt] || 0) + v;
    }
  }
  let max = 0;
  for (const dt of Object.keys(daySums)){ if (daySums[dt] > max) max = daySums[dt]; }
  return max;
}

function mTimeRange(){
  const sel = M$("memTimeFrame");
  const v = sel ? sel.value : "mtd";
  const today = new Date();
  const todayStr = mDs(today);
  if (v === "today") return {from: todayStr, to: todayStr, label: "Today"};
  if (v === "7d"){ const d = new Date(today); d.setDate(d.getDate() - 6); return {from: mDs(d), to: todayStr, label: "Last 7 days"}; }
  if (v === "30d"){ const d = new Date(today); d.setDate(d.getDate() - 29); return {from: mDs(d), to: todayStr, label: "Last 30 days"}; }
  if (v === "mtd") return {from: todayStr.slice(0, 8) + "01", to: todayStr, label: "Month to date"};
  if (v === "ytd") return {from: today.getFullYear() + "-01-01", to: todayStr, label: "Year to date"};
  if (/^\d{4}-\d{2}$/.test(v)){
    const p = v.split("-"); const y = parseInt(p[0]), m = parseInt(p[1]) - 1;
    const start = new Date(y, m, 1); const end = new Date(y, m + 1, 0);
    return {from: mDs(start), to: end > today ? todayStr : mDs(end), label: start.toLocaleString("en-US", {month: "long", year: "numeric"})};
  }
  if (/^\d{4}$/.test(v)){
    const y = parseInt(v);
    return {from: y + "-01-01", to: y === today.getFullYear() ? todayStr : y + "-12-31", label: v};
  }
  return {from: todayStr.slice(0, 8) + "01", to: todayStr, label: "Month to date"};
}

function mPopulateTimeFrame(){
  const sel = M$("memTimeFrame");
  if (!sel) return;
  const cur = sel.value || "mtd";
  const today = new Date();
  let html = '<option value="today">Today</option><option value="7d">Last 7 days</option><option value="30d">Last 30 days</option><option value="mtd">Month to date</option>';
  html += '<optgroup label="Months">';
  for (let i = 1; i <= 24; i++){
    const d = mAddMonths(today, -i); const k = mMonthKey(d);
    html += '<option value="' + k + '">' + d.toLocaleString("en-US", {month: "long", year: "numeric"}) + '</option>';
  }
  html += '</optgroup><option value="ytd">Year to date</option><optgroup label="Years">';
  for (let y = today.getFullYear(); y >= today.getFullYear() - 5; y--) html += '<option value="' + y + '">' + y + '</option>';
  html += '</optgroup>';
  sel.innerHTML = html;
  sel.value = cur;
}

function mRenderTiles(){
  const el = M$("memTiles");
  if (!el) return;
  const tr = mTimeRange();
  const r = mMemberRange(tr.from, tr.to);
  const fromD = new Date(tr.from + "T00:00:00");
  const toD = new Date(tr.to + "T00:00:00");
  const days = Math.max(1, Math.round((toD - fromD) / 86400000) + 1);
  const members = mLatestVehicles() || Object.keys(mConsumers).length;
  const ath = mAllTimeHigh();
  el.innerHTML =
    mTile("Active members (vehicles)", members) +
    mTile("All-time high", ath || "--") +
    mTile("Member sales (" + tr.label + ")", mMoney0(r.rev)) +
    mTile("Pass uses", r.passUse.toLocaleString("en-US")) +
    mTile("Member $/wash", r.passUse ? "$" + (r.rev / r.passUse).toFixed(2) : "--") +
    mTile("Avg daily revenue", mMoney0(r.rev / days));
}

function mLatestVehicles(){
  let tot = 0;
  for (const s of mFilteredSites()){
    const days = Object.keys(mHist[s.id] || {}).sort();
    for (let i = days.length - 1; i >= 0; i--){
      const v = mHist[s.id][days[i]].consumerVehicles || 0;
      if (v){ tot += v; break; }
    }
  }
  return tot;
}

function mMonthAgg(){
  const out = {};
  for (const s of mFilteredSites()){
    for (const dt of Object.keys(mHist[s.id] || {})){
      const mk = dt.slice(0, 7);
      const r = mHist[s.id][dt];
      const o = out[mk] = out[mk] || {news: 0, cancels: 0, declines: 0, renewAmt: 0, renews: 0};
      o.news += (r.newPass || 0) + (r.newPassOnline || 0);
      o.cancels += r.passCancelled || 0;
      o.declines += r.declined || 0;
      o.renewAmt += r.passRenewAmt || 0;
      o.renews += r.passRenew || 0;
    }
  }
  return out;
}

function mRenderEconomics(){
  const el = M$("memLtv");
  const agg = mMonthAgg();
  const now = new Date();
  const full = [];
  for (let i = 1; i <= 3; i++){
    const k = mMonthKey(mAddMonths(now, -i));
    if (agg[k]) full.push(agg[k]);
  }
  const members = mLatestVehicles() || Object.keys(mConsumers).length;
  if (!full.length || !members){ el.innerHTML = "<div class=\"stat\"><label>Economics</label><div>Need consumer sync + report history</div></div>"; return; }
  const cancels = full.reduce((a, x) => a + x.cancels, 0) / full.length;
  const renewAmt = full.reduce((a, x) => a + x.renewAmt, 0);
  const renews = full.reduce((a, x) => a + x.renews, 0);
  const churn = cancels / members;
  const avgPrice = renews ? renewAmt / renews : 0;
  const lifeMo = churn > 0 ? 1 / churn : null;
  const ltv = lifeMo && avgPrice ? avgPrice * lifeMo : null;
  el.innerHTML =
    "<div class=\"stat\"><label>Active members (vehicles)</label><div>" + members + "</div></div>" +
    "<div class=\"stat\"><label>Monthly churn</label><div>" + (churn * 100).toFixed(1) + "%</div></div>" +
    "<div class=\"stat\"><label>Avg renewal price</label><div>" + mMoney(avgPrice) + "</div></div>" +
    "<div class=\"stat\"><label>Est. avg lifetime</label><div>" + (lifeMo ? lifeMo.toFixed(1) + " mo" : "--") + "</div></div>" +
    "<div class=\"stat\"><label>Est. LTV</label><div>" + (ltv ? mMoney(ltv) : "--") + "</div></div>";
}

function mRenderNet(){
  const tb = M$("memNetBody");
  tb.innerHTML = "";
  const agg = mMonthAgg();
  const keys = Object.keys(agg).sort().slice(-13);
  if (!keys.length){ tb.innerHTML = "<tr><td colspan=\"5\">No report history. Press Sync on Overview.</td></tr>"; return; }
  for (const k of keys.reverse()){
    const o = agg[k];
    const net = o.news - o.cancels;
    const tr = document.createElement("tr");
    tr.innerHTML = "<td>" + mMonthLabel(k) + "</td><td>" + o.news + "</td><td>" + o.cancels + "</td><td>" + (net >= 0 ? "+" : "") + net + "</td><td>" + o.declines + "</td>";
    tb.appendChild(tr);
  }
}

async function mRenderConversions(){
  await platesLoad();
  const el = M$("memConversions");
  if (!el) return;
  const si = mSelectedSite ? pSiteIdx(mSelectedSite, mSites) : null;
  const conv = plateConversions(si, null, null);
  el.innerHTML = "<h2>New Pass Conversion \u2014 Prior Retail Visits</h2>" + pRenderConversionsHtml(conv);
}

function mTenureRate(c){
  const mo = c.signup ? Math.min(12, Math.max((Date.now() - c.signup) / 2592000000, 1)) : 12;
  return c.washes / (mo * (c.veh || 1));
}
function mRecentRateVeh(c){
  return mRecentRate(c) / (c.veh || 1);
}

function mBarChart(buckets, labels, color){
  const max = Math.max.apply(null, buckets.map(b => b)) || 1;
  let html = '<div style="display:flex;align-items:flex-end;gap:4px;height:130px;margin:8px 0 4px">';
  for (let i = 0; i < buckets.length; i++){
    const pct = buckets[i] / max * 100;
    const h = Math.max(pct, buckets[i] ? 3 : 0);
    html += '<div style="flex:1;text-align:center;display:flex;flex-direction:column;justify-content:flex-end;height:100%">' +
      '<div style="font-size:11px;color:#b9c6da;margin-bottom:2px">' + (buckets[i] || '') + '</div>' +
      '<div style="background:' + color + ';height:' + h + '%;min-height:' + (buckets[i] ? 2 : 0) + 'px;border-radius:3px 3px 0 0"></div>' +
      '<div style="font-size:11px;color:#8fa3c0;margin-top:3px">' + labels[i] + '</div></div>';
  }
  html += '</div>';
  return html;
}

function mRenderFrequency(){
  const el = M$("memFrequency");
  if (!el) return;
  const active = Object.values(mConsumers).filter(c => {
    if (mIsCancelled(c)) return false;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    return lastBill && Date.now() - lastBill <= 45 * 86400000;
  });
  if (!active.length){ el.innerHTML = "<p>No active members with usage data.</p>"; return; }
  const labels = ["0x","1x","2x","3x","4x","5x","6x","7x","8x+"];
  const recentBuckets = new Array(9).fill(0);
  for (const c of active){
    const r = Math.round(mRecentRateVeh(c));
    recentBuckets[Math.min(r, 8)]++;
  }
  el.innerHTML = mBarChart(recentBuckets, labels, "#4f8ef7");
}

function mRenderTierBreakdown(){
  const el = M$("memTiers");
  if (!el) return;
  const active = Object.values(mConsumers).filter(c => {
    if (mIsCancelled(c)) return false;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    return lastBill && Date.now() - lastBill <= 45 * 86400000;
  });
  const tiers = {};
  for (const c of active){
    const plan = c.washPlan || "Unknown";
    tiers[plan] = (tiers[plan] || 0) + 1;
  }
  const sorted = Object.entries(tiers).sort((a, b) => b[1] - a[1]);
  if (!sorted.length){ el.innerHTML = "<p>No tier data. Run a consumer sync to populate.</p>"; return; }
  const total = active.length;
  let html = "";
  for (const [plan, count] of sorted){
    const pct = (count / total * 100).toFixed(1);
    html += mTile(plan, count + " (" + pct + "%)");
  }
  el.innerHTML = html;
}

function mRenderCancelTiming(){
  const el = M$("memCancelChart");
  const tb = M$("memCancelBody");
  if (!el || !tb) return;
  const cancelled = Object.values(mConsumers).filter(c => {
    return c.cancelled && c.signup && c.cancelled > (c.lastNew || 0);
  });
  if (!cancelled.length){
    el.innerHTML = "<p>No cancellation data yet.</p>";
    tb.innerHTML = "";
    return;
  }
  const bucketLabels = ["Mo 1","Mo 2","Mo 3","Mo 4","Mo 5","Mo 6","Mo 7-12","12+"];
  const buckets = new Array(8).fill(0);
  for (const c of cancelled){
    const months = (c.cancelled - c.signup) / (30.44 * 86400000);
    if (months < 1) buckets[0]++;
    else if (months < 2) buckets[1]++;
    else if (months < 3) buckets[2]++;
    else if (months < 4) buckets[3]++;
    else if (months < 5) buckets[4]++;
    else if (months < 6) buckets[5]++;
    else if (months < 12) buckets[6]++;
    else buckets[7]++;
  }
  el.innerHTML = mBarChart(buckets, bucketLabels, "#f87171");
  tb.innerHTML = "";
  const total = cancelled.length;
  for (let i = 0; i < bucketLabels.length; i++){
    if (!buckets[i]) continue;
    const tr = document.createElement("tr");
    const pct = (buckets[i] / total * 100).toFixed(1);
    tr.innerHTML = "<td>" + bucketLabels[i] + "</td><td>" + buckets[i] + "</td><td>" + pct + "%</td>";
    tb.appendChild(tr);
  }
}

function mRenderVehicles(){
  const el = M$("memVehicles");
  if (!el) return;
  const active = Object.values(mConsumers).filter(c => {
    if (mIsCancelled(c)) return false;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    return lastBill && Date.now() - lastBill <= 45 * 86400000;
  });
  const multi = active.filter(c => (c.veh || 1) >= 2);
  const breakdown = {};
  for (const c of multi){
    const v = c.veh || 1;
    const key = v >= 4 ? "4+" : String(v);
    breakdown[key] = (breakdown[key] || 0) + 1;
  }
  let brkHtml = "";
  for (const k of ["2", "3", "4+"]){
    if (breakdown[k]) brkHtml += mTile(k + "-vehicle plans", breakdown[k]);
  }
  el.innerHTML =
    mTile("Multi-vehicle plans", multi.length) +
    mTile("% of active members", active.length
      ? (multi.length / active.length * 100).toFixed(1) + "%"
      : "--") +
    mTile("Avg vehicles (multi)", multi.length
      ? (multi.reduce((a, c) => a + (c.veh || 1), 0) / multi.length).toFixed(1)
      : "--") +
    brkHtml;
}

function mMemberRangeFull(from, to){
  var out = {rev: 0, passUse: 0, news: 0, cancels: 0, declined: 0};
  for (var s of mFilteredSites()){
    for (var dt of Object.keys(mHist[s.id] || {})){
      if (dt < from || dt > to) continue;
      var r = mHist[s.id][dt];
      out.rev += (r.newPassAmt || 0) + (r.passRenewAmt || 0) + (r.newPassOnlineAmt || 0) + (r.onlineGiftAmt || 0) + (r.viaAddAmt || 0);
      out.passUse += r.passUse || 0;
      out.news += (r.newPass || 0) + (r.newPassOnline || 0);
      out.cancels += r.passCancelled || 0;
      out.declined += r.declined || 0;
    }
  }
  out.net = out.news - out.cancels;
  return out;
}

function mMemberSiteRange(sid, from, to){
  var out = {rev: 0, passUse: 0, news: 0, cancels: 0, declined: 0};
  for (var dt of Object.keys(mHist[sid] || {})){
    if (dt < from || dt > to) continue;
    var r = mHist[sid][dt];
    out.rev += (r.newPassAmt || 0) + (r.passRenewAmt || 0) + (r.newPassOnlineAmt || 0) + (r.onlineGiftAmt || 0) + (r.viaAddAmt || 0);
    out.passUse += r.passUse || 0;
    out.news += (r.newPass || 0) + (r.newPassOnline || 0);
    out.cancels += r.passCancelled || 0;
    out.declined += r.declined || 0;
  }
  out.net = out.news - out.cancels;
  return out;
}

function mYoyPc(cur, ly){ return ly ? Math.round((cur - ly) / Math.abs(ly) * 100) : null; }
function mYoySpan(pct){ if (pct === null) return ""; return " <span class=\"delta " + (pct >= 0 ? "up" : "down") + "\">" + (pct >= 0 ? "+" : "") + pct + "%</span>"; }

function mRenderYoY(){
  var el = M$("memYoY");
  if (!el) return;
  var today = new Date();
  var todayStr = mDs(today);
  var moStart = todayStr.slice(0,8) + "01";
  var ytdStart = todayStr.slice(0,4) + "-01-01";
  var lyRef = new Date(today); lyRef.setFullYear(lyRef.getFullYear() - 1);
  var lyMoStart = mDs(lyRef).slice(0,8) + "01", lyMoEnd = mDs(lyRef);
  var lyYtdStart = mDs(lyRef).slice(0,4) + "-01-01", lyYtdEnd = mDs(lyRef);

  var mtd = mMemberRangeFull(moStart, todayStr);
  var lyMtd = mMemberRangeFull(lyMoStart, lyMoEnd);
  var ytd = mMemberRangeFull(ytdStart, todayStr);
  var lyYtd = mMemberRangeFull(lyYtdStart, lyYtdEnd);

  var html = "";
  html += mTile("Revenue vs LY (MTD)", mMoney0(mtd.rev) + mYoySpan(mYoyPc(mtd.rev, lyMtd.rev)) + "<br><small>LY: " + mMoney0(lyMtd.rev) + "</small>");
  html += mTile("Revenue vs LY (YTD)", mMoney0(ytd.rev) + mYoySpan(mYoyPc(ytd.rev, lyYtd.rev)) + "<br><small>LY: " + mMoney0(lyYtd.rev) + "</small>");
  html += mTile("New passes vs LY (MTD)", mtd.news + mYoySpan(mYoyPc(mtd.news, lyMtd.news)) + "<br><small>LY: " + lyMtd.news + "</small>");
  html += mTile("New passes vs LY (YTD)", ytd.news + mYoySpan(mYoyPc(ytd.news, lyYtd.news)) + "<br><small>LY: " + lyYtd.news + "</small>");
  html += mTile("Cancels vs LY (MTD)", mtd.cancels + mYoySpan(mYoyPc(mtd.cancels, lyMtd.cancels)) + "<br><small>LY: " + lyMtd.cancels + "</small>");
  html += mTile("Cancels vs LY (YTD)", ytd.cancels + mYoySpan(mYoyPc(ytd.cancels, lyYtd.cancels)) + "<br><small>LY: " + lyYtd.cancels + "</small>");
  var netPcMtd = lyMtd.net ? mYoyPc(mtd.net, lyMtd.net) : null;
  var netPcYtd = lyYtd.net ? mYoyPc(ytd.net, lyYtd.net) : null;
  html += mTile("Net vs LY (MTD)", (mtd.net >= 0 ? "+" : "") + mtd.net + mYoySpan(netPcMtd) + "<br><small>LY: " + (lyMtd.net >= 0 ? "+" : "") + lyMtd.net + "</small>");
  html += mTile("Net vs LY (YTD)", (ytd.net >= 0 ? "+" : "") + ytd.net + mYoySpan(netPcYtd) + "<br><small>LY: " + (lyYtd.net >= 0 ? "+" : "") + lyYtd.net + "</small>");
  html += mTile("Member washes vs LY (MTD)", mtd.passUse.toLocaleString() + mYoySpan(mYoyPc(mtd.passUse, lyMtd.passUse)) + "<br><small>LY: " + lyMtd.passUse.toLocaleString() + "</small>");
  html += mTile("Member washes vs LY (YTD)", ytd.passUse.toLocaleString() + mYoySpan(mYoyPc(ytd.passUse, lyYtd.passUse)) + "<br><small>LY: " + lyYtd.passUse.toLocaleString() + "</small>");
  var mPer = function(o){ return o.passUse ? o.rev / o.passUse : 0; };
  html += mTile("Member $/wash vs LY (MTD)", "$" + mPer(mtd).toFixed(2) + mYoySpan(mYoyPc(mPer(mtd), mPer(lyMtd))) + "<br><small>LY: $" + mPer(lyMtd).toFixed(2) + "</small>");
  html += mTile("Member $/wash vs LY (YTD)", "$" + mPer(ytd).toFixed(2) + mYoySpan(mYoyPc(mPer(ytd), mPer(lyYtd))) + "<br><small>LY: $" + mPer(lyYtd).toFixed(2) + "</small>");

  var cwrap = M$("memYoYChartWrap");
  if (cwrap) cwrap.innerHTML = '<div id="memYoYToggles" style="margin-bottom:6px"></div><div id="memYoYView" style="margin-bottom:10px"></div><canvas id="memYoYChart" style="width:100%"></canvas>';
  // Per-site table
  if (mSites.length > 1){
    html += "<table class=\"via\" style=\"margin-top:12px\"><thead><tr><th>Site</th><th>Rev MTD</th><th>LY</th><th>YoY</th><th>Rev YTD</th><th>LY</th><th>YoY</th><th>New MTD</th><th>LY</th><th>Cancel MTD</th><th>LY</th></tr></thead><tbody>";
    for (var si of mFilteredSites()){
      var sm = mMemberSiteRange(si.id, moStart, todayStr);
      var slm = mMemberSiteRange(si.id, lyMoStart, lyMoEnd);
      var sy = mMemberSiteRange(si.id, ytdStart, todayStr);
      var sly = mMemberSiteRange(si.id, lyYtdStart, lyYtdEnd);
      var smPc = mYoyPc(sm.rev, slm.rev);
      var syPc = mYoyPc(sy.rev, sly.rev);
      html += "<tr><td>" + si.name + "</td>" +
        "<td>" + mMoney0(sm.rev) + "</td><td>" + mMoney0(slm.rev) + "</td><td>" + (smPc !== null ? (smPc >= 0 ? "+" : "") + smPc + "%" : "--") + "</td>" +
        "<td>" + mMoney0(sy.rev) + "</td><td>" + mMoney0(sly.rev) + "</td><td>" + (syPc !== null ? (syPc >= 0 ? "+" : "") + syPc + "%" : "--") + "</td>" +
        "<td>" + sm.news + "</td><td>" + slm.news + "</td>" +
        "<td>" + sm.cancels + "</td><td>" + slm.cancels + "</td></tr>";
    }
    html += "</tbody></table>";
  }
  el.innerHTML = html;
  // Render YoY chart
  setTimeout(function(){
    var cv = M$("memYoYChart");
    if (!cv || typeof wlYoYChart !== "function") return;
    var metrics = [
      {key: "rev", label: "Revenue", extract: function(r){ return r.rev; }, fmt: mMoney0},
      {key: "news", label: "New Passes", extract: function(r){ return r.news; }, fmt: function(v){ return Math.round(v).toLocaleString(); }},
      {key: "cancels", label: "Cancels", extract: function(r){ return r.cancels; }, fmt: function(v){ return Math.round(v).toLocaleString(); }},
      {key: "net", label: "Net", extract: function(r){ return r.net; }, fmt: function(v){ return (v >= 0 ? "+" : "") + Math.round(v).toLocaleString(); }},
      {key: "uses", label: "Member washes", extract: function(r){ return r.passUse; }, fmt: function(v){ return Math.round(v).toLocaleString(); }}
    ];
    var curM = "rev", curV = "mtd";
    function memByDay(extractFn){
      var out = {};
      for (var si of mFilteredSites()){
        for (var dt of Object.keys(mHist[si.id] || {})){
          var r = mHist[si.id][dt];
          var val = extractFn({
            rev: (r.newPassAmt||0)+(r.passRenewAmt||0)+(r.newPassOnlineAmt||0)+(r.onlineGiftAmt||0)+(r.viaAddAmt||0),
            news: (r.newPass||0)+(r.newPassOnline||0),
            cancels: r.passCancelled||0,
            passUse: r.passUse||0,
            net: (r.newPass||0)+(r.newPassOnline||0)-(r.passCancelled||0)
          });
          out[dt] = (out[dt]||0) + val;
        }
      }
      return out;
    }
    function mtdData(byDay){
      var today = new Date(), yr = today.getFullYear(), mo = today.getMonth(), dn = today.getDate();
      var ty = [], ly = [], lb = [];
      for (var d = 1; d <= dn; d++){
        ty.push(byDay[mDs(new Date(yr, mo, d))]||0);
        ly.push(byDay[mDs(new Date(yr-1, mo, d))]||0);
        lb.push(String(d));
      }
      return {tyVals: ty, lyVals: ly, labels: lb};
    }
    function mo12Data(byDay){
      var today = new Date(), ty = [], ly = [], lb = [];
      for (var i = 11; i >= 0; i--){
        var mr = new Date(today.getFullYear(), today.getMonth()-i, 1);
        var me = new Date(mr.getFullYear(), mr.getMonth()+1, 0);
        var lr = new Date(mr.getFullYear()-1, mr.getMonth(), 1);
        var le = new Date(lr.getFullYear(), lr.getMonth()+1, 0);
        if (mr.getFullYear()===today.getFullYear() && mr.getMonth()===today.getMonth()){ me=today; le=new Date(today.getFullYear()-1,today.getMonth(),today.getDate()); }
        var t=0, l=0;
        for (var dt of Object.keys(byDay)){ if (dt>=mDs(mr)&&dt<=mDs(me)) t+=byDay[dt]; if (dt>=mDs(lr)&&dt<=mDs(le)) l+=byDay[dt]; }
        ty.push(t); ly.push(l); lb.push(mr.toLocaleString("en-US",{month:"short"}));
      }
      return {tyVals: ty, lyVals: ly, labels: lb};
    }
    function draw(){
      var mf = metrics.find(function(m){ return m.key === curM; });
      var byDay = memByDay(mf.extract);
      var data = curV === "mtd" ? mtdData(byDay) : mo12Data(byDay);
      wlYoYChart(cv, data.tyVals, data.lyVals, data.labels, {fmtFn: mf.fmt});
    }
    function btn(l,a){ return '<button style="padding:5px 12px;border-radius:6px;border:1px solid #3a4a63;background:'+(a?'#4da3ff':'#1a2233')+';color:#eaeef5;cursor:pointer;margin-right:5px;font-size:12px">'+l+'</button>'; }
    function renderT(){
      var te = M$("memYoYToggles"), ve = M$("memYoYView");
      if (!te||!ve) return;
      var mH = ""; for (var m of metrics) mH += btn(m.label, m.key === curM);
      te.innerHTML = mH; ve.innerHTML = btn("This Month", curV==="mtd") + btn("Last 12 Months", curV==="12mo");
      var mBs = te.querySelectorAll("button"); for (var i=0;i<mBs.length;i++)(function(idx){mBs[idx].addEventListener("click",function(){curM=metrics[idx].key;renderT();draw();});})(i);
      var vBs = ve.querySelectorAll("button"); vBs[0].addEventListener("click",function(){curV="mtd";renderT();draw();}); vBs[1].addEventListener("click",function(){curV="12mo";renderT();draw();});
    }
    renderT(); draw();
  }, 50);
}

async function memRender(){
  const st = M$("memStatus");
  st.textContent = "Calculating...";
  const failed = [];
  const run = async function(name, fn){
    try { await fn(); }
    catch (e){ console.error("[Sidecar] Members section failed: " + name, e); failed.push(name); }
  };
  try { await memLoad(); }
  catch (e){ console.error("[Sidecar] memLoad failed", e); st.textContent = "Load failed - see console"; return; }
  await run("tiles", mRenderTiles);
  await run("yoy", mRenderYoY);
  await run("economics", mRenderEconomics);
  await run("vehicles", mRenderVehicles);
  await run("tiers", mRenderTierBreakdown);
  await run("usage-split", mRenderUsageSplit);
  await run("chart", mRenderChart);
  await run("tips-tiles", function(){ if (typeof wlTips === "function"){ wlTips("memTiles", WL_TIP_MEM_TILES); } });
  await run("incomplete", mRenderIncomplete);
  await run("lost", mRenderLostMembers);
  await run("risk", mRenderRisk);
  await run("cohorts", mRenderCohorts);
  await run("frequency", mRenderFrequency);
  await run("cancel-timing", mRenderCancelTiming);
  await run("tips-ltv", function(){ if (typeof wlTips === "function"){ wlTips("memLtv", WL_TIP_MEM_ECON); } });
  await run("net", mRenderNet);
  await run("conversions", mRenderConversions);
  st.textContent = failed.length ? ("Some sections failed: " + failed.join(", ")) : "";
}

function mPopulateSiteFilter(){
  const sel = M$("memSiteFilter");
  if (!sel || !mSites.length) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">All Sites</option>' +
    mSites.filter(s => !s.name.includes("COMING SOON")).map(s =>
      '<option value="' + s.id + '"' + (s.id === cur ? ' selected' : '') + '>' + s.name + '</option>'
    ).join("");
}

onReady( () => {
  M$("memRefreshBtn").addEventListener("click", memRender);
  const mSiteFilter = M$("memSiteFilter");
  if (mSiteFilter) mSiteFilter.addEventListener("change", () => {
    mSelectedSite = mSiteFilter.value || null;
    memRender();
  });
  mInitCollapsible();
  const memLP = M$("memLostPeriod");
  if (memLP) memLP.addEventListener("change", mRenderLostMembers);
  const memTF = M$("memTimeFrame");
  if (memTF) memTF.addEventListener("change", () => { memRender(); });
  mPopulateTimeFrame();
  memRender().then(() => { mPopulateSiteFilter(); });
});
