const C$ = (id) => document.getElementById(id);
let consumers = {};
let consSortCol = "signup";
let consSortAsc = false;

function cEsc(s){ const d = document.createElement("div"); d.textContent = s || ""; return d.innerHTML; }
function cNorm(s){ return (s || "").toLowerCase().replace(/[^a-z]/g, ""); }
function consFmtDate(t){ if (!t) return "--"; try { const d = new Date(t); if (isNaN(d.getTime())) return "--"; return (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear(); } catch(e){ return "--"; } }

async function consLoad(){
  const st = (await chrome.storage.local.get(["consumers"])) || {};
  consumers = st.consumers || {};
}
async function consSave(){ await chrome.storage.local.set({consumers: consumers}); }

async function fetchConsumerPage(page){
  const body = "ConsumerFirstName=&ConsumerLastName=&MobileNumber=&Email=&RFIDCode=&ConsumerCode=0&CreditCardStatus=&HasMultiplePasses=false&CurrentPage=" + page + "&ItemsPerPage=500";
  const res = await safeFetch(DENCAR_BASE + "/consumer/indexfiltertable/", {method: "POST", credentials: "include", headers: {"Content-Type": "application/x-www-form-urlencoded"}, body: body});
  if (!res.ok) return [];
  const doc = new DOMParser().parseFromString(await res.text(), "text/html");
  const out = [];
  doc.querySelectorAll("div.card[id]").forEach(card => {
    const id = (card.getAttribute("id") || "").trim();
    if (!/^[0-9a-fA-F-]{36}$/.test(id)) return;
    const h = card.querySelector("h5");
    let name = "", signup = 0;
    if (h){
      const small = h.querySelector("small");
      const dTxt = small ? small.textContent.trim() : "";
      const dm = dTxt.match(/(\d{2})\/(\d{2})\/(\d{4})/);
      if (dm) signup = new Date(dm[3], dm[1] - 1, dm[2]).getTime();
      const hClone = h.cloneNode(true);
      const sm = hClone.querySelector("small");
      if (sm) sm.remove();
      name = hClone.textContent.replace(/\s+/g, " ").trim();
    }
    out.push({id: id, name: name || "(no name)", signup: signup});
  });
  return out;
}

async function fetchPaymentsPage(page, startStr, endStr, siteId){
  const body = "currentPage=" + page + "&itemsPerPage=500&PaymentType=&SiteId=" + encodeURIComponent(siteId || "") + "&DeviceId=&StartDate=" + startStr + "&EndDate=" + endStr + "&LicensePlateNum=&Code=&MaskedCardNumber=&ConsumerFirstName=&ConsumerLastName=&ConsumerId=";
  const res = await safeFetch(DENCAR_BASE + "/Payment/IndexFilterTable", {method: "POST", credentials: "include", headers: {"Content-Type": "application/x-www-form-urlencoded"}, body: body});
  if (!res.ok) return null;
  const txt = await res.text();
  if (txt.indexOf("customerlogin") >= 0 || txt.indexOf("ReturnUrl") >= 0) return null;
  const doc = new DOMParser().parseFromString(txt, "text/html");
  const rows = Array.from(doc.querySelectorAll("tr"));
  let tsIdx = -1, lpIdx = -1, mIdx = -1, nIdx = -1;
  let aIdx = -1, taxIdx = -1, dIdx = -1;
  for (const r of rows){
    Array.from(r.children).forEach((c, i) => {
      const t = c.textContent.trim().toLowerCase();
      if (c.tagName !== "TH") return;
      if (tsIdx === -1 && /timestamp/.test(t)) tsIdx = i;
      if (lpIdx === -1 && /license|plate/.test(t) && !/confidence/.test(t)) lpIdx = i;
      if (mIdx === -1 && t === "method") mIdx = i;
      if (nIdx === -1 && t === "name") nIdx = i;
      if (aIdx === -1 && t === "amount") aIdx = i;
      if (taxIdx === -1 && t === "tax") taxIdx = i;
      if (dIdx === -1 && t === "device") dIdx = i;
    });
    if (tsIdx >= 0 && lpIdx >= 0 && mIdx >= 0 && nIdx >= 0) break;
  }
  const out = [];
  for (const r of rows){
    const cells = Array.from(r.children);
    if (!cells.length || cells[0].tagName === "TH") continue;
    let ts = tsIdx >= 0 && cells[tsIdx] ? cells[tsIdx].textContent.trim() : "";
    if (!/^\d{2}\/\d{2}\/\d{4}/.test(ts)){
      const alt = cells.map(c => c.textContent.trim()).find(x => /^\d{2}\/\d{2}\/\d{4}/.test(x));
      if (alt) ts = alt; else continue;
    }
    const p = ts.split(/[\/ :]/);
    const t = new Date(p[2], p[0] - 1, p[1], p[3] || 0, p[4] || 0, p[5] || 0).getTime();
    out.push({
      t: t,
      lp: (lpIdx >= 0 && cells[lpIdx] ? cells[lpIdx].textContent.trim() : "").toUpperCase(),
      method: mIdx >= 0 && cells[mIdx] ? cells[mIdx].textContent.trim() : "",
      name: nIdx >= 0 && cells[nIdx] ? cells[nIdx].textContent.replace(/\s+/g, " ").trim() : "",
      amt: aIdx >= 0 && cells[aIdx] ? (parseFloat(cells[aIdx].textContent.replace(/[^0-9.-]/g, "")) || 0) : 0,
      tax: taxIdx >= 0 && cells[taxIdx] ? (parseFloat(cells[taxIdx].textContent.replace(/[^0-9.-]/g, "")) || 0) : 0,
      device: dIdx >= 0 && cells[dIdx] ? cells[dIdx].textContent.replace(/\s+/g, " ").trim() : ""
    });
  }
  return out;
}

function consIsLogin(res){ return /\/customerlogin\//i.test((res && res.url) || ""); }
async function fetchVehicleCount(id){
  try {
    // Step 1: fetch consumer page to find their pass link
    const cRes = await safeFetch(DENCAR_BASE + "/consumer/" + id + "/", {credentials: "include", redirect: "manual"});
    if (!cRes.ok || cRes.type === "opaqueredirect" || cRes.status === 0) return -1;
    if (consIsLogin(cRes)) return -1;
    const cDoc = new DOMParser().parseFromString(await cRes.text(), "text/html");
    let cPhone = "", cFavSite = "";
    for (const s of cDoc.querySelectorAll("strong")){
      const t = s.textContent.trim();
      if (/^phone\s*#?$/i.test(t)){ const p = s.nextElementSibling; if (p) cPhone = p.textContent.trim(); }
      if (/^favorite\s*site$/i.test(t)){ const p = s.nextElementSibling; if (p) cFavSite = p.textContent.trim().split("\n")[0].trim(); }
    }
    let passUrl = "";
    cDoc.querySelectorAll('a[href*="/consumerpass/"]').forEach(a => {
      const m = (a.getAttribute("href") || "").match(/\/consumerpass\/([0-9a-fA-F-]{36})\//);
      if (m) passUrl = "/consumerpass/" + m[1] + "/";
    });
    if (!passUrl) return {veh: 1, washPlan: "", phone: cPhone, favSite: cFavSite};
    // Step 2: fetch pass page, read Vehicle Count <strong> + <p>
    const res = await safeFetch(DENCAR_BASE + passUrl, {credentials: "include", redirect: "manual"});
    if (!res.ok || res.type === "opaqueredirect" || res.status === 0) return -1;
    if (consIsLogin(res)) return -1;
    const doc = new DOMParser().parseFromString(await res.text(), "text/html");
    let veh = 1, washPlan = "";
    for (const s of doc.querySelectorAll("strong")){
      const t = s.textContent.trim();
      if (/^vehicle\s*count$/i.test(t)){
        const p = s.nextElementSibling;
        if (p){ const n = parseInt(p.textContent); if (n > 0) veh = n; }
      }
      if (/^wash\s*pass$/i.test(t)){
        const p = s.nextElementSibling;
        if (p) washPlan = p.textContent.trim();
      }
    }
    return {veh: veh, washPlan: washPlan, phone: cPhone, favSite: cFavSite};
  } catch(e){ console.error("[Sidecar] fetchVehicleCount failed", id, e); return -1; }
}

async function fetchConsumerPhone(id){
  try {
    const res = await safeFetch(DENCAR_BASE + "/consumer/" + id + "/", {credentials: "include", redirect: "manual"});
    if (!res.ok || res.type === "opaqueredirect" || res.status === 0) return null;
    const doc = new DOMParser().parseFromString(await res.text(), "text/html");
    let phone = "", site = "";
    for (const s of doc.querySelectorAll("strong")){
      const t = s.textContent.trim();
      if (/^phone\s*#?$/i.test(t)){
        const p = s.nextElementSibling;
        if (p) phone = p.textContent.trim();
      }
      if (/^favorite\s*site$/i.test(t)){
        const p = s.nextElementSibling;
        if (p) site = p.textContent.trim().split("\n")[0].trim();
      }
    }
    return {phone: phone, favSite: site};
  } catch(e){ return null; }
}

async function fetchIncompletePhones(fresh){
  const cut = Date.now() - 35 * 86400000;
  const ids = Object.keys(fresh).filter(id => {
    const c = fresh[id];
    return c.name === "(no name)" && c.signup > cut && !c.phone;
  });
  for (let i = 0; i < ids.length; i++){
    C$("consStatus").textContent = "Fetching incomplete signup " + (i + 1) + "/" + ids.length + "...";
    const info = await fetchConsumerPhone(ids[i]);
    if (info === null){ consumers = fresh; await consSave(); break; }
    fresh[ids[i]].phone = info.phone;
    fresh[ids[i]].favSite = info.favSite;
    if (i % 5 === 4){ consumers = fresh; await consSave(); }
    await new Promise(r => setTimeout(r, 100));
  }
}

async function fetchLostMemberInfo(fresh){
  const cut = Date.now() - 365 * 86400000;
  const ids = Object.keys(fresh).filter(id => {
    const c = fresh[id];
    if (c.phone) return false;
    const lastBill = Math.max(c.lastNew || 0, c.lastRenew || 0);
    if (!lastBill || lastBill < cut) return false;
    if (c.cancelled && c.cancelled > (c.lastNew || 0) && c.cancelled > cut) return true;
    if (lastBill < Date.now() - 45 * 86400000) return true;
    return false;
  });
  if (!ids.length) return;
  for (let i = 0; i < ids.length; i++){
    C$("consStatus").textContent = "Fetching lost member info " + (i + 1) + "/" + ids.length + "...";
    const v = await fetchVehicleCount(ids[i]);
    if (v === -1) break;
    if (v.phone) fresh[ids[i]].phone = v.phone;
    if (v.favSite) fresh[ids[i]].favSite = v.favSite;
    if (v.washPlan) fresh[ids[i]].washPlan = v.washPlan;
    fresh[ids[i]].veh = v.veh;
    if (i % 10 === 9){ consumers = fresh; await consSave(); }
    await new Promise(r => setTimeout(r, 100));
  }
  consumers = fresh;
  await consSave();
}

async function fetchVehBatch(ids, fresh){
  for (let i = 0; i < ids.length; i++){
    C$("consStatus").textContent = "Fetching vehicle count " + (i + 1) + "/" + ids.length + "...";
    const v = await fetchVehicleCount(ids[i]);
    if (v === -1){ C$("consStatus").textContent = "Dencar session expired at " + (i + 1) + "/" + ids.length + ". Log in to Dencar and re-sync."; consumers = fresh; await consSave(); renderConsumers(); C$("consSyncBtn").disabled = false; throw new Error("SESSION_EXPIRED"); }
    fresh[ids[i]].veh = v.veh; fresh[ids[i]].vehChecked = true; if (v.washPlan) fresh[ids[i]].washPlan = v.washPlan; if (v.phone) fresh[ids[i]].phone = v.phone; if (v.favSite) fresh[ids[i]].favSite = v.favSite;
    if (i % 10 === 9){ consumers = fresh; await consSave(); }
    await new Promise(r => setTimeout(r, 100));
  }
}

// Rebuilds per-member usage (washes by device + membership $ paid) one month at a time, then fills in
// any missing favorite sites. Saves as it goes and resumes where it stopped. Leaves other consumer fields alone.
// Covers payments through the last Consumers sync; later syncs add newer payments on their own.
const CONS_USAGE_V = 2;

// Asks Dencar for recent payments one site at a time (its own Site filter), so every device name seen
// is tied to a site ID - no guessing from names. Aborts if the filter doesn't actually narrow by site.
async function consLearnDeviceMap(say){
  say = say || function(){};
  const st = (await chrome.storage.local.get(["sites", "deviceSiteMap"])) || {};
  const sites = st.sites || [];
  if (!sites.length) return false;
  const end = new Date().toLocaleDateString("en-CA");
  const sd = new Date(); sd.setDate(sd.getDate() - 90);
  const start = sd.toLocaleDateString("en-CA");
  const seen = {};
  for (const site of sites){
    for (let page = 1; page <= 6; page++){
      say("Matching devices to sites: " + site.name + (page > 1 ? " (page " + page + ")" : "") + "...");
      let batch = null;
      for (let tries = 0; tries < 3 && !batch; tries++){
        try { batch = await fetchPaymentsPage(page, start, end, site.id); } catch (e) { batch = null; }
        if (!batch) await new Promise(function(r){ setTimeout(r, 1500 * (tries + 1)); });
      }
      if (!batch) return false;
      for (const row of batch){
        const d = (row.device || "").replace(/\s+/g, " ").trim();
        if (!d) continue;
        if (seen[d] && seen[d] !== site.id){ say("Dencar's payment filter doesn't separate sites, so devices are matched by which site's members use them instead."); return false; }
        seen[d] = site.id;
      }
      if (batch.length < 500) break;
    }
  }
  if (!Object.keys(seen).length) return false;
  await chrome.storage.local.set({ deviceSiteMap: Object.assign({}, st.deviceSiteMap || {}, seen), deviceSiteMapAt: Date.now() });
  return true;
}
async function consFillFavSites(say){
  const ids = Object.keys(consumers).filter(function(id){
    const c = consumers[id];
    return c.use && Object.keys(c.use).length && !c.favSite && !c.favChecked;
  }).sort(function(a, b){
    const la = Object.keys(consumers[a].use).sort().pop() || "", lb = Object.keys(consumers[b].use).sort().pop() || "";
    return la < lb ? 1 : -1;
  });
  for (let i = 0; i < ids.length; i++){
    say("Looking up favorite sites: " + (i + 1) + " of " + ids.length + "...");
    let info = null;
    for (let tries = 0; tries < 3 && !info; tries++){
      info = await fetchConsumerPhone(ids[i]);
      if (!info) await new Promise(function(r){ setTimeout(r, 1500 * (tries + 1)); });
    }
    if (!info){ await consSave(); return false; }
    const c = consumers[ids[i]];
    if (info.favSite) c.favSite = info.favSite;
    if (info.phone && !c.phone) c.phone = info.phone;
    c.favChecked = true;
    if (i % 10 === 9) await consSave();
    await new Promise(function(r){ setTimeout(r, 80); });
  }
  await consSave();
  return true;
}

async function consRebuildUsage(say){
  say = say || function(){};
  const st = (await chrome.storage.local.get(["consumers", "lastPaymentSync", "usageRebuild"])) || {};
  if (!st.lastPaymentSync || !st.consumers || !Object.keys(st.consumers).length){
    say("Run Sync Payment History on the Consumers page first.");
    return false;
  }
  consumers = st.consumers;
  let ck = st.usageRebuild || {};
  if (ck.v !== CONS_USAGE_V) ck = {};
  const B = ck.boundary && !ck.monthsComplete ? st.lastPaymentSync : (ck.boundary || st.lastPaymentSync);
  const nextMonth = function(mk){ const y = +mk.slice(0, 4), m = +mk.slice(5, 7); return m === 12 ? (y + 1) + "-01" : y + "-" + String(m + 1).padStart(2, "0"); };
  const monthEnd = function(mk){ const y = +mk.slice(0, 4), m = +mk.slice(5, 7); return new Date(y, m, 0).toLocaleDateString("en-CA"); };
  let first = "2015-01";
  let minSign = null;
  for (const c of Object.values(consumers)) if (c.signup && (!minSign || c.signup < minSign)) minSign = c.signup;
  if (minSign){ const f = new Date(minSign).toLocaleDateString("en-CA").slice(0, 7); if (f > first) first = f; }
  const lastMk = B.slice(0, 7);
  const byName = {};
  for (const c of Object.values(consumers)){ const k = cNorm(c.name); if (k) byName[k] = c; }
  const sleep = function(ms){ return new Promise(function(r){ setTimeout(r, ms); }); };
  const csb = document.getElementById("consSyncBtn");
  if (csb) csb.disabled = true;
  try {
    await consLearnDeviceMap(say);
    if (!ck.monthsComplete){
      let mk = ck.done ? nextMonth(ck.done) : first;
      let total = 0, idx = 0;
      for (let m = first; m <= lastMk; m = nextMonth(m)) total++;
      for (let m = first; m < mk; m = nextMonth(m)) idx++;
      for (; mk <= lastMk; mk = nextMonth(mk)){
        idx++;
        const from = mk + "-01";
        let to = monthEnd(mk);
        if (to > B) to = B;
        const tmp = {};
        for (let page = 1; page <= 400; page++){
          say("Rebuilding usage: " + mk + " (month " + idx + " of " + total + ", page " + page + ")...");
          let batch = null;
          for (let tries = 0; tries < 4; tries++){
            try { batch = await fetchPaymentsPage(page, from, to); } catch (e) { batch = null; }
            if (batch) break;
            await sleep(2000 * (tries + 1));
          }
          if (!batch){
            say("Stopped at " + mk + " (Dencar didn't respond or the session expired). Progress is saved - log in to Dencar if needed and press Resume to continue.");
            return false;
          }
          for (const row of batch){
            if (!/wash pass|new pass|pass renew/i.test(row.method)) continue;
            const c = byName[cNorm(row.name)];
            if (!c) continue;
            const u = tmp[c.id] = tmp[c.id] || { w: {}, p: 0 };
            if (/wash pass/i.test(row.method)){
              const ws = (row.device || "").replace(/\s+/g, " ").trim() || "Unknown";
              u.w[ws] = (u.w[ws] || 0) + 1;
            } else {
              u.p = Math.round((u.p + Math.max(0, (row.amt || 0) - (row.tax || 0))) * 100) / 100;
            }
          }
          if (batch.length < 500) break;
          await sleep(30);
        }
        for (const c of Object.values(consumers)){
          if (c.use && c.use[mk]) delete c.use[mk];
          if (tmp[c.id]){ c.use = c.use || {}; c.use[mk] = tmp[c.id]; }
        }
        ck = { v: CONS_USAGE_V, boundary: B, done: mk, monthsComplete: mk === lastMk, complete: false };
        await chrome.storage.local.set({ consumers: consumers, usageRebuild: ck });
      }
      ck = { v: CONS_USAGE_V, boundary: B, done: lastMk, monthsComplete: true, complete: false };
      await chrome.storage.local.set({ usageRebuild: ck });
    }
    const favOk = await consFillFavSites(say);
    if (!favOk){
      say("Stopped while looking up favorite sites (Dencar didn't respond or the session expired). Progress is saved - press Resume to continue.");
      return false;
    }
    ck.complete = true;
    await chrome.storage.local.set({ usageRebuild: ck });
    say("Usage history rebuilt through " + B + ".");
    return true;
  } finally {
    if (csb) csb.disabled = false;
  }
}

async function consSync(opts){
  const forceFull = !!(opts && opts.forceFull === true);
  C$("consSyncBtn").disabled = true;
  C$("consStatus").textContent = "Loading consumer list...";
  try {
    const list = [];
    for (let page = 1; page <= 10; page++){
      C$("consStatus").textContent = "Loading consumer list page " + page + "...";
      const batch = await fetchConsumerPage(page);
      list.push.apply(list, batch);
      if (batch.length < 500) break;
      await new Promise(r => setTimeout(r, 20));
    }
    if (!list.length){ C$("consStatus").textContent = "No consumers found - are you logged into Dencar?"; C$("consSyncBtn").disabled = false; return; }
    const stored = (await chrome.storage.local.get(["washTiers", "plateVisits", "plateSiteMap", "lastPaymentSync"])) || {};
    const tiers = stored.washTiers || {};
    const pv = stored.plateVisits || {};
    const psm = stored.plateSiteMap || [];
    const hasWashData = Object.values(consumers).some(function(c){ return c.washes > 0; });
    const isIncr = !forceFull && !!stored.lastPaymentSync && hasWashData;
    const byName = {};
    const fresh = {};
    for (const c of list){
      const prev = consumers[c.id] || null;
      const ex = isIncr ? prev : null;
      fresh[c.id] = ex
        ? {id: c.id, name: c.name, signup: c.signup, washes: ex.washes || 0, others: ex.others || 0, lastWash: ex.lastWash || 0, months: Object.assign({}, ex.months), use: JSON.parse(JSON.stringify(ex.use || {})), cancelled: ex.cancelled || 0, lastNew: ex.lastNew || 0, lastRenew: ex.lastRenew || 0, veh: ex.veh || 1, vehChecked: ex.vehChecked || false, phone: ex.phone || "", favSite: ex.favSite || "", washPlan: ex.washPlan || ""}
        : {id: c.id, name: c.name, signup: c.signup, washes: 0, others: 0, lastWash: 0, months: {}, use: {}, cancelled: 0, lastNew: 0, lastRenew: 0,
           veh: prev ? (prev.veh || 1) : 1, vehChecked: prev ? !!prev.vehChecked : false, phone: prev ? (prev.phone || "") : "", favSite: prev ? (prev.favSite || "") : "", washPlan: prev ? (prev.washPlan || "") : ""};
      const k = cNorm(c.name);
      if (k) byName[k] = fresh[c.id];
    }
    const endStr = new Date().toLocaleDateString("en-CA");
    let startStr;
    if (isIncr){
      const lpd = new Date(stored.lastPaymentSync + "T12:00:00");
      lpd.setDate(lpd.getDate() + 1);
      startStr = lpd.toLocaleDateString("en-CA");
      if (startStr > endStr){
        const vehCut2 = Date.now() - 45 * 86400000;
        const vehIds2 = Object.keys(fresh).filter(id => {
          const c = fresh[id];
          return !c.vehChecked && ((c.lastWash > vehCut2) || (c.lastRenew > vehCut2) || (c.lastNew > vehCut2));
        });
        if (vehIds2.length){
          await fetchVehBatch(vehIds2, fresh);
        }
        await fetchIncompletePhones(fresh);
        await fetchLostMemberInfo(fresh);
        consumers = fresh;
        await consSave();
        C$("consStatus").textContent = "Up to date. " + list.length + " consumers.";
        renderConsumers();
        C$("consSyncBtn").disabled = false;
        return;
      }
      C$("consStatus").textContent = "Incremental sync from " + startStr + "...";
    } else {
      startStr = "2015-01-01";
    }
    let latestPayDate = startStr;
    for (let page = 1; page <= 500; page++){
      C$("consStatus").textContent = "Loading payments page " + page + "...";
      const batch = await fetchPaymentsPage(page, startStr, endStr);
      if (batch === null){
        consumers = fresh;
        await chrome.storage.local.set({consumers: consumers, washTiers: tiers, plateVisits: pv, plateSiteMap: psm, lastPaymentSync: latestPayDate});
        C$("consStatus").textContent = "Dencar session expired at page " + page + ". Saved progress through " + latestPayDate + ". Log in and re-sync.";
        renderConsumers();
        C$("consSyncBtn").disabled = false;
        return;
      }
      for (const row of batch){
        if (/^(credit card|cash)$/i.test(row.method) && row.amt > 0){
          const site = (row.device || "").split(" - ")[0].trim() || "Unknown";
          const base = Math.round((row.amt - row.tax) * 100) / 100;
          const key = (Math.abs(base - Math.round(base)) < 0.02 && base > 0) ? String(Math.round(base)) : "other";
          const dk = new Date(row.t).toLocaleDateString("en-CA");
          const sObj = tiers[site] = tiers[site] || {};
          const dObj = sObj[dk] = sObj[dk] || {};
          const cur = dObj[key] = dObj[key] || [0, 0];
          cur[0] += 1;
          cur[1] += base;
        }
        if (row.lp && row.lp !== "N/A" && row.lp !== "-"){
          const pSite = (row.device || "").split(" - ")[0].trim() || "Unknown";
          let psi = psm.indexOf(pSite);
          if (psi === -1){ psi = psm.length; psm.push(pSite); }
          const pdk = new Date(row.t).toLocaleDateString("en-CA");
          if (/^(credit card|cash)$/i.test(row.method)){
            const pr = pv[row.lp] = pv[row.lp] || {v: []};
            if (!pr.v.some(function(e){ return e[0] === pdk && e[1] === psi; })) pr.v.push([pdk, psi]);
          }
          if (/new pass/i.test(row.method)){
            const pr = pv[row.lp] = pv[row.lp] || {v: []};
            pr.conv = pdk;
          }
        }
        const c = byName[cNorm(row.name)];
        if (!c) continue;
        const rowDate = new Date(row.t).toLocaleDateString("en-CA");
        if (rowDate > latestPayDate) latestPayDate = rowDate;
        if (/wash pass|new pass|pass renew/i.test(row.method)){
          const umk = rowDate.slice(0, 7);
          c.use = c.use || {};
          const u = c.use[umk] = c.use[umk] || {w: {}, p: 0};
          if (/wash pass/i.test(row.method)){
            const ws = (row.device || "").replace(/\s+/g, " ").trim() || "Unknown";
            u.w[ws] = (u.w[ws] || 0) + 1;
          } else {
            u.p = Math.round((u.p + Math.max(0, (row.amt || 0) - (row.tax || 0))) * 100) / 100;
          }
        }
        if (/pass cancelled/i.test(row.method)){ if (row.t > c.cancelled) c.cancelled = row.t; }
        if (/new pass/i.test(row.method)){ if (row.t > c.lastNew) c.lastNew = row.t; }
        if (/pass renew/i.test(row.method)){ if (row.t > c.lastRenew) c.lastRenew = row.t; }
        if (/wash pass/i.test(row.method)){
          c.washes++;
          const md = new Date(row.t);
          const mk = md.getFullYear() + "-" + String(md.getMonth() + 1).padStart(2, "0");
          c.months[mk] = (c.months[mk] || 0) + 1;
          if (row.t > c.lastWash) c.lastWash = row.t;
        } else if (/vac|self serve/i.test(row.method)){
          c.others++;
        }
      }
      /* Checkpoint every 25 pages to survive failures */
      if (page % 5 === 0){
        consumers = fresh;
        await chrome.storage.local.set({consumers: consumers, washTiers: tiers, plateVisits: pv, plateSiteMap: psm, lastPaymentSync: latestPayDate});
        C$("consStatus").textContent = "Checkpoint saved at page " + page + "...";
      }
      if (batch.length < 500) break;
      await new Promise(r => setTimeout(r, 20));
    }
    const vehCut = Date.now() - 45 * 86400000;
    const vehIds = Object.keys(fresh).filter(id => {
      const c = fresh[id];
      return !c.vehChecked && ((c.lastWash > vehCut) || (c.lastRenew > vehCut) || (c.lastNew > vehCut));
    });
    if (vehIds.length){
      await fetchVehBatch(vehIds, fresh);
    }
    await fetchIncompletePhones(fresh);
    await fetchLostMemberInfo(fresh);
    consumers = fresh;
    await chrome.storage.local.set({washTiers: tiers, plateVisits: pv, plateSiteMap: psm, lastPaymentSync: endStr});
    await consSave();
    C$("consStatus").textContent = "Synced " + list.length + " consumers" + (isIncr ? " (incremental from " + startStr + ")" : " (full history)") + ".";
    renderConsumers();
  } catch(e){
    C$("consStatus").textContent = "Consumer sync failed: " + e.message;
  }
  C$("consSyncBtn").disabled = false;
}

function consPerMonth(c){ const mo = c.signup ? Math.min(12, Math.max((Date.now() - c.signup) / 2592000000, 1)) : 12; return c.washes / (mo * (c.veh || 1)); }

function renderConsumers(){
  const tb = C$("consBody");
  tb.innerHTML = "";
  const sq = (C$("consSearch") ? C$("consSearch").value : "").toLowerCase().replace(/[^a-z0-9+]/g, "");
  const arr = Object.values(consumers).filter(c => {
    if (!sq) return true;
    const n = (c.name || "").toLowerCase();
    const p = (c.phone || "").toLowerCase();
    return n.indexOf(sq) >= 0 || p.indexOf(sq) >= 0;
  });
  if (!arr.length){ tb.innerHTML = "<tr><td colspan=\"8\">No consumers loaded. Press Sync Consumers.</td></tr>"; return; }
  const colVal = (c, col) => {
    if (col === "name") return (c.name || "").toLowerCase();
    if (col === "signup") return c.signup || 0;
    if (col === "cars") return c.veh || 1;
    if (col === "washes") return c.washes || 0;
    if (col === "perMonth") return consPerMonth(c);
    if (col === "others") return c.others || 0;
    if (col === "lastWash") return c.lastWash || 0;
    return 0;
  };
  arr.sort((a, b) => {
    const av = colVal(a, consSortCol), bv = colVal(b, consSortCol);
    const cmp = av < bv ? -1 : av > bv ? 1 : 0;
    return consSortAsc ? cmp : -cmp;
  });
  document.querySelectorAll("#consHead th[data-col]").forEach(th => {
    const arrow = th.dataset.col === consSortCol ? (consSortAsc ? " \u25B2" : " \u25BC") : "";
    th.textContent = th.dataset.label + arrow;
  });
  for (const c of arr){
    const tr = document.createElement("tr");
    tr.innerHTML = "<td>" + cEsc(c.name) + "</td><td>" + consFmtDate(c.signup) + "</td><td>" + (c.veh || 1) + "</td><td>" + c.washes + "</td><td>" + consPerMonth(c).toFixed(1) + "/car</td><td>" + c.others + "</td><td>" + consFmtDate(c.lastWash) + "</td><td><a class=\"via-open\" target=\"_blank\" href=\"" + DENCAR_BASE + "/consumer/" + c.id + "/\">Open</a></td>";
    tb.appendChild(tr);
  }
}

onReady( async () => {
  C$("consSyncBtn").addEventListener("click", consSync);
  if (C$("consSearch")) C$("consSearch").addEventListener("input", renderConsumers);
  document.querySelectorAll("#consHead th[data-col]").forEach(th => {
    th.style.cursor = "pointer";
    th.addEventListener("click", () => {
      if (consSortCol === th.dataset.col) consSortAsc = !consSortAsc;
      else { consSortCol = th.dataset.col; consSortAsc = th.dataset.col === "name"; }
      renderConsumers();
    });
  });
  await consLoad();
  try { renderConsumers(); } catch(e){ console.warn("renderConsumers failed:", e); }
});
